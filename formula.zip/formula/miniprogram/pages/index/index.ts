interface Group {
  startTime: string;
  count: number;
}

Page({
  data: {
    loadingTime: '', // 装药时间
    averageDosage: 0,
    groups: [] as Group[],
    totalDosage: null as number | null,
    totalPatients: 0,
    totalTime: '' // 总耗时
  },

  onLoad() {
    // 初始化 4 组
    this.addGroup();
    this.addGroup();
    this.addGroup();
    this.addGroup();
  },

  bindLoadingTimeChange(e: WechatMiniprogram.PickerChange) {
    const value = e.detail.value;
    const time = Array.isArray(value) ? value.join(':') : value;
    this.setData({
      loadingTime: time // 选择的装药时间
    });
  },

  bindAverageDosageInput(e: WechatMiniprogram.Input) {
    this.setData({
      averageDosage: parseFloat(e.detail.value) || 0
    });
  },

  bindGroupStartTimeChange(e: WechatMiniprogram.PickerChange) {
    const groupIndex = parseInt(e.currentTarget.dataset.group, 10); // 获取组别索引
    const value = e.detail.value;
    const time = Array.isArray(value) ? value.join(':') : value;
    const groups = [...this.data.groups];
    
    // 确保该组已初始化
    if (!groups[groupIndex]) {
      groups[groupIndex] = { startTime: '', count: 0 };
    }
    
    groups[groupIndex].startTime = time;
    this.setData({ groups });
  },

  bindGroupCountInput(e: WechatMiniprogram.Input) {
    const groupIndex = parseInt(e.currentTarget.dataset.group, 10);
    const count = parseInt(e.detail.value, 10);
    const groups = [...this.data.groups];

    groups[groupIndex].count = count;
    this.setData({ groups });
  },

  addGroup() {
    const groups = [...this.data.groups];
    groups.push({ startTime: '', count: 0 });
    this.setData({ groups });
  },

  calculateTotalDosage() {
    const { loadingTime, averageDosage, groups } = this.data;
    if (!loadingTime || averageDosage <= 0) return;

    const loadingTimeMinutes = this.timeToMinutes(loadingTime); // 装药时间转换为分钟
    let totalDosage = 0;
    let lastInjectionTimeMinutes = loadingTimeMinutes; // 用于计算总耗时

    groups.forEach(group => {
      const groupStartMinutes = this.timeToMinutes(group.startTime); // 组开始时间转换为分钟
      const interval = 3; // 注射间隔时间（分钟）

      for (let i = 0; i < group.count; i++) {
        const injectionTimeMinutes = groupStartMinutes - loadingTimeMinutes + i * interval;
        const decayFactor = Math.exp(-Math.log(2) / 110 * injectionTimeMinutes);
        totalDosage += averageDosage / decayFactor;
        lastInjectionTimeMinutes = Math.max(lastInjectionTimeMinutes, groupStartMinutes + i * interval);
      }
    });

    // 计算总耗时
    const totalMinutes = lastInjectionTimeMinutes - loadingTimeMinutes;
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;

    this.setData({
      totalDosage: parseFloat(totalDosage.toFixed(2)), // 保留两位小数
      totalPatients: groups.reduce((total, group) => total + group.count, 0),
      totalTime: `${hours}小时${minutes}分钟` // 格式化总耗时
    });
  },

  timeToMinutes(time: string): number {
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
  }
});
